﻿The Alsing.Text namespace contains my old DFA tokenizer.
This is not documented and there are no samples other than the usage in Alsing Framework - NPath

Documentation and samples will come in time ;-)


