﻿namespace Alsing.SourceCode
{
    /// <summary>
    /// 
    /// </summary>
    public delegate void RowEventHandler(object sender, RowEventArgs e);
}