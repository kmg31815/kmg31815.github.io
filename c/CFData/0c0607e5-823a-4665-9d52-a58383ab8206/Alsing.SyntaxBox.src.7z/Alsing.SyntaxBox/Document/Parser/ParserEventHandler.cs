﻿namespace Alsing.SourceCode
{
    /// <summary>
    /// Parser event handler
    /// </summary>
    public delegate void ParserEventHandler(object sender, RowEventArgs e);
}